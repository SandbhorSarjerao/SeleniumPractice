package testNG;

public class ScreenShotOfFailedTestCases 
{
	
}
